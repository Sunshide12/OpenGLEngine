﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “macossin”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/834513

*NOTE: “HCTrees” was originally cloned (copied) from the FontStruction
“SwiftedStrokes” (https://fontstruct.com/fontstructions/show/398094) by Mike
Lee, which is licensed under a Creative Commons Attribution Share Alike license
(http://creativecommons.org/licenses/by-sa/3.0/).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2013-2026 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
